package Mensaje;

import java.io.Serializable;

public class Mensaje implements Serializable{
	
	public String name;
	public boolean left, right, up, down;
	public boolean jump;
	public boolean arma;

}
