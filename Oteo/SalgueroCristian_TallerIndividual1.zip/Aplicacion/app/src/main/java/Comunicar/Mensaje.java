package Comunicar;

import java.io.Serializable;

public class Mensaje implements Serializable {

    public String NAME;
    public boolean RIGHT, LEFT, UP, DOWN, ATACK, START;

}
